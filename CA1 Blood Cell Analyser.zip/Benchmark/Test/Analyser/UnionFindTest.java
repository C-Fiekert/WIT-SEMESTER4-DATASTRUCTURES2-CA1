///Packages///
package Analyser;

///Imports///
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

///UnionFind Test Class///
public class UnionFindTest {

    //Fields
    int[] pixel;

    //Set-up before testing
    @Before
    public void setUp() throws Exception {
        pixel = new int[5];
        pixel[0] = 2;
        pixel[1] = 4;
        pixel[2] = 1;
        pixel[3] = 3;
        pixel[4] = 3;
    }

    //Checks if the find2 method returns the root
    @Test
    public void find2Test() {
        assertTrue("The method found the incorrect root", UnionFind.find2(pixel, 0) == 3);
    }
}