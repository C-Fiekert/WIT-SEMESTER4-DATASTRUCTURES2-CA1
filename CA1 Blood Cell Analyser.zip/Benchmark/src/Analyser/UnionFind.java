///Packages///
package Analyser;

///UnionFind Class///
public class UnionFind {

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        //METHODS//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //Find method
    public static int find2(int[] a, int id) {
        //Returns -1
        if(id == -1){
            return -1;
        }
        //Returns array position value
        else if (a[id] == id)
            return id;
        else
            //Returns array position root
            return find2(a, a[id]);
    }

    //Union method
    public static void union(int[] p, int i, int d) {
        p[find2(p,d)] = find2(p,i);
    }
}