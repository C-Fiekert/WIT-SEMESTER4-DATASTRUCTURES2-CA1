///Packages///
package Analyser;
///Imports///
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

///Main Class///
public class Main extends Application {
    ///Launches Application///
    @Override
    public void start(Stage primaryStage) throws Exception{
        //Gets FXML
        Parent root = FXMLLoader.load(getClass().getResource("BloodCell.fxml"));
        //Sets title
        primaryStage.setTitle("Blood Cell Analyser");
        //Sets icon
        primaryStage.getIcons().add(new Image("https://cdn0.iconfinder.com/data/icons/the-human-body-color/128/blood-drop-red-512.png"));
        //Sets window size
        primaryStage.setScene(new Scene(root, 900, 600));
        //Shows GUI
        primaryStage.show();
    }
    public static void main(String[] args) {
        launch(args);
    }
}