///Packages///
package Analyser;

///Imports///
//Javafx
import javafx.scene.control.Slider;
import javafx.scene.control.Tooltip;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.image.*;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import java.awt.*;
//JMH Benchmarking
import org.openjdk.jmh.annotations.*;
import java.util.concurrent.TimeUnit;
//Hashset & union method
import java.util.HashSet;
import static Analyser.UnionFind.find2;
import static Analyser.UnionFind.union;

///Utilities Class///
@Measurement(iterations = 10)
@Warmup(iterations = 5)
@Fork(value = 1)
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.MILLISECONDS)
@State(Scope.Thread)
public class Utilities {

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        //FIELDS//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //Writable image for tricolour, count cells & visual noise reduction
    static WritableImage wImage;
    //Arrays used for reading pixels from image
    static int[] pixel, repeat, white;
    //Hashset for counting total cells
    static HashSet<Integer> total = new HashSet<>();
    //Hashset for counting number of white cells
    static HashSet<Integer> whiteHash = new HashSet<>();
    //Initializes values for different rectangle lines
    static int topLine;// = height;
    static int bottomLine;// = 0;
    static int leftLine;// = width;
    static int rightLine;// = 0;
    //Keeps track of sequential cell counting
    static int count = 1;

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        //METHODS//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //Tricolour conversion method
    public static WritableImage tricolour(Image image, ImageView imgImage2) {
        //Reads each pixel
        PixelReader pixelReader = image.getPixelReader();
        int width = (int) image.getWidth();
        int height = (int) image.getHeight();
        //Creating a writable image
        wImage = new WritableImage(width, height);
        //Initializes arrays
        pixel = new int[width * height];
        repeat = new int[width * height];
        white = new int[width * height];

        for (int i = 0; i < pixel.length; i++) {
            pixel[i] = i;
        }
        //Creating the pixel writer
        PixelWriter writer = wImage.getPixelWriter();

        //Reading the color of the image
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                //Retrieving the color of the pixel of the loaded image
                Color color = pixelReader.getColor(x, y);
                //Sets pixel to white
                if (color.getRed() * 255 > 210) {
                    writer.setColor(x, y, Color.WHITE);
                }
                //Sets pixel to purple
                else if (color.getBlue() > color.getRed()) {
                    writer.setColor(x, y, Color.PURPLE);
                }
                //Sets pixel to red
                else {
                    writer.setColor(x, y, Color.RED);
                }
            }
        }
        //Setting the view for the writable image
        imgImage2.setImage(wImage);
        return wImage;
    }

    //Count cells method
    //@Benchmark
    public static int countCells(Slider min) {
        //Empties the total & whitehash hashset
        total.clear();
        whiteHash.clear();
        int width = (int) wImage.getWidth();
        int height = (int) wImage.getHeight();

        PixelReader pixelreader = wImage.getPixelReader();

        //Any white pixels in tricolour set to -1 in pixel array
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                Color color = pixelreader.getColor(x, y);
                if (color.equals(Color.WHITE)) {
                    pixel[(y * width) + x] = -1;
                }
            }
        }

        //Unions the pixels together
        for (int id = 0; id < pixel.length; id++) {
            if (pixel[id] != -1) {
                //Unions the pixel to the right
                if ((id < pixel.length - 1) && ((id+1) % width != 0) && (pixel[id + 1] != -1)) {
                    union(pixel, id, id + 1);
                }
                //Unions the pixel below
                if ((id + width < pixel.length) && (pixel[id + width] != -1)) {
                    union(pixel, id, id + width);
                }
            }
        }

        //Adds each cell size to the repeat array
        for (int i = 0; i < pixel.length; i++) {
            repeat[i] = 0;
            white[i] = 0;
            if (pixel[i] != -1) {
                repeat[pixel[i]]++;
            }
        }

        // Noise Reduction
        //Only adds cells above a certain size to the total hashset
        for (int i = 0; i < repeat.length; i++) {
            if (repeat[i] >= min.getValue()*1.4110) {
                total.add(i);
            }
        }

        //Count white cells
        //Adds the white cell size to the white array
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                Color color = pixelreader.getColor(x, y);
                if (color.equals(Color.PURPLE)) {
                    white[pixel[y * width + x]]++;
                }
            }
        }
        //Only adds white cells above a certain size to the whiteHash hashset
        for (int i = 0; i < white.length; i++) {
            if (white[i] > min.getValue() * 3.635120) {
                whiteHash.add(white[i]);
            }
        }
        //Returns the total number of cells
        return total.size();
    }

    //Visual noise reduction method
    public static WritableImage noiseReduce(Slider value) {
        //Creates pixelwriter
        PixelWriter writer = wImage.getPixelWriter();
        for (int y = 0; y < wImage.getHeight(); y++) {
            for (int x = 0; x < wImage.getWidth(); x++) {
                //Set the pixels in cell less than given size to white
                if(find2(pixel,y * (int) wImage.getWidth() + x) != -1 && repeat[find2(pixel,y * (int) wImage.getWidth() + x)] < value.getValue())
                    writer.setColor(x, y, Color.WHITE);
            }
        }
        return wImage;
    }

    //Sets the hue, saturation and brightness
    public static WritableImage adjust(Image image, ImageView imgImage2, Slider hue, Slider saturation, Slider brightness) {
        ColorAdjust colorAdjust = new ColorAdjust();
        //Sets the hue
        colorAdjust.setHue(hue.getValue() / 100);
        //Sets the brightness
        colorAdjust.setBrightness(brightness.getValue() / 100);
        //Sets the saturation
        colorAdjust.setSaturation(saturation.getValue() / 100);

        //Adds effect to the imageview
        imgImage2.setEffect(colorAdjust);
        imgImage2.setImage(image);
        return new WritableImage(10, 10);
    }

    //Create rectangle method
    public static Rectangle bound(int cell) {
        int width = (int) wImage.getWidth();
        int height = (int) wImage.getHeight();
        //Initializes values for different lines
        int topLine = height;
        int bottomLine = 0;
        int leftLine = width;
        int rightLine = 0;
        Rectangle rec;
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                //If pixel root matches value
                if (find2(pixel, y * width + x) == cell) {
                    //Stores the highest pixel
                    if (y < topLine) {
                        topLine = y;
                    }
                    //Stores the lowest pixel
                    if (y > bottomLine) {
                        bottomLine = y;
                    }
                    //Stores the left most pixel
                    if (x < leftLine) {
                        leftLine = x;
                    }
                    //Stores the right most pixel
                    if (x > rightLine) {
                        rightLine = x;
                    }
                }
            }
        }

        //Creates the rectangle
        rec = new Rectangle(leftLine, topLine, rightLine - leftLine, bottomLine - topLine);
        rec.setFill(Color.TRANSPARENT);
        Tooltip.install(rec, new Tooltip("TEST"));

        //Totals the number of purple pixels and other colour pixels
        int purple = 0;
        int other = 0;
        for (int y = topLine; y < bottomLine; y++) {
            for (int x = leftLine; x < rightLine; x++) {
                PixelReader pixelreader = wImage.getPixelReader();
                Color color = pixelreader.getColor(x, y);
                if (color.equals(Color.PURPLE)) {
                    purple++;
                } else {
                    other++;
                }
            }
        }
        //If there are more purple pixels, set the rectangle to purple
        if (purple >= other){
            rec.setStroke(Color.PURPLE);
            Tooltip.install(rec, new Tooltip("White Blood Cell"));
        } else if(purple + other > 8000){
            rec.setStroke(Color.BLUE);
            Tooltip.install(rec, new Tooltip("Cluster of Cells"));
        } else {
            rec.setStroke(Color.GREEN);
            Tooltip.install(rec, new Tooltip("Red Blood Cell"));
        }
        //Returns the rectangle
        return rec;
    }

    //Creates each number for sequential counting
    public static Text seqCount(int cell){
        int width = (int) wImage.getWidth();
        int height = (int) wImage.getHeight();
        //Initializes values for different lines
        int topLine = height;
        int bottomLine = 0;
        int leftLine = width;
        int rightLine = 0;
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                //If pixel root matches value
                if (find2(pixel, y * width + x) == cell) {
                    //Stores the highest pixel
                    if (y < topLine) {
                        topLine = y;
                    }
                    //Stores the lowest pixel
                    if (y > bottomLine) {
                        bottomLine = y;
                    }
                    //Stores the left most pixel
                    if (x < leftLine) {
                        leftLine = x;
                    }
                    //Stores the right most pixel
                    if (x > rightLine) {
                        rightLine = x;
                    }
                }
            }
        }

        Text text;
        text = new Text(leftLine + 4, bottomLine - 4, String.valueOf(count));
        text.setFill(Color.WHITE);
        text.setFont(new Font(12));
        text.setStroke(Color.WHITE);
        count++;
        return text;
    }
}