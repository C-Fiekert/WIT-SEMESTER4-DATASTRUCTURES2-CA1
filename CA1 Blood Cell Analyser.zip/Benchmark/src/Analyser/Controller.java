///Packages///
package Analyser;
///Imports///
//Javafx
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
//JMH Benchmarking
import org.openjdk.jmh.annotations.*;
import java.util.concurrent.TimeUnit;
//File input
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

///Controller Class///
@Measurement(iterations = 10)
@Warmup(iterations = 5)
@Fork(value = 1)
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.MILLISECONDS)
@State(Scope.Thread)
public class Controller {

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                            //FIELDS//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //Image placeholders
    @FXML
    ImageView original, adjustment, analyseBlood, background, background2, background3;
    //Window box
    @FXML
    VBox node;
    //Adjustable sliders
    @FXML
    Slider hue, saturation, brightness, minimum;
    //Labels show number of cells
    @FXML
    Label total, red, white;
    //Action buttons
    @FXML
    Button outline, setting, analyse, noise;
    //Pane for outline rectangles
    @FXML
    Pane pane;
    @FXML
    CheckBox seqCount;
    //Imported image
    Image originalp;
    Image back = new Image("https://st4.depositphotos.com/11246114/21860/i/450/depositphotos_218605656-stock-photo-wood-washed-background-surface-light.jpg", 900, 569.6, false, true);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        //METHODS//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public void initialize(){
        background.setImage(back);
        background2.setImage(back);
        background3.setImage(back);
    }

    //Open image method
    public void open() throws FileNotFoundException {
        //Creates file chooser
        FileChooser fc = new FileChooser();
        File selectedFile = fc.showOpenDialog(node.getScene().getWindow());
        //Checks if file is an image
        if (selectedFile.getName().endsWith(".jpeg") || selectedFile.getName().endsWith(".jpg") || selectedFile.getName().endsWith(".png") || selectedFile.getName().endsWith(".jfif")) {
            //Grabs selected file
            FileInputStream hello = new FileInputStream(selectedFile);
            originalp = new Image(hello, 512, 350, false, true);

            //Displays the original image
            original.setImage(originalp);
            //Displays the adjustable image
            adjustment.setImage(Utilities.tricolour(originalp, adjustment));
            //Displays the tricolour image to analyse
            analyseBlood.setImage(Utilities.tricolour(originalp, analyseBlood));

            //Clears any previously displayed rectangles
            pane.getChildren().clear();
            //Changes action buttons status
            outline.setDisable(true);
            setting.setDisable(false);
            analyse.setDisable(false);
        }
        else{
            //Alerts user of incorrect file type
            Alertbox.alert("Blood Cell Analyser", "Please use an image file", "Click ok to continue");
        }
    }

    //Visual noise reduction method
    public void reduceNoise(){
        adjustment.setImage(Utilities.noiseReduce(minimum));
        adjustment.setImage(Utilities.tricolour(originalp, adjustment));
        outline.setDisable(true);
    }

    //Adjust hue, saturation & brightness method
    public void apply(){
        adjustment.setImage(Utilities.adjust(originalp, adjustment, hue, saturation, brightness));
        adjustment.setImage(Utilities.adjust(originalp, analyseBlood, hue, saturation, brightness));
        adjustment.setImage(Utilities.tricolour(originalp, adjustment));
        adjustment.setImage(Utilities.tricolour(originalp, analyseBlood));
    }

    //Count cells method
    @Benchmark
    public void count(){
        Utilities.countCells(minimum);
        total.setText(String.valueOf(Utilities.countCells(minimum)));
        white.setText(String.valueOf(Utilities.whiteHash.size()));
        red.setText(String.valueOf(Utilities.countCells(minimum) - Utilities.whiteHash.size()));
        outline.setDisable(false);
        noise.setDisable(false);
    }

    //Outline cells with rectangles method
    public void outlineCells(){
        pane.getChildren().clear();
        Utilities.count = 1;
          for(int id : Utilities.total){
            pane.getChildren().add(Utilities.bound(id));
            if (seqCount.isSelected()) {
                pane.getChildren().add(Utilities.seqCount(id));
            }
        }
    }


    //Reset original image method
    public void reset(){
        pane.getChildren().clear();
        Utilities.count = 1;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        //EXIT//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //Exit system
    public void quit(){
        System.exit(0);
    }
}